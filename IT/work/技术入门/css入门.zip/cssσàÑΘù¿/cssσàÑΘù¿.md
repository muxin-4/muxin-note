# web技术入门

web技术主要分为HTML css javascript HTTP

[MDN Web 技术文档](https://developer.mozilla.org/zh-CN/docs/Web)



###1. html 阅读文档

- [入门 菜鸟教程](http://www.runoob.com/html/html-tutorial.html)（看完就入门html）
- [HTML最全的手册： MDN HTML](https://developer.mozilla.org/zh-CN/docs/Web/HTML)（入门后，再读MDN HTML，这个是官方编写的，包含很多特性）



###2.css学习在于实践和总结，换句话说光看不写是雾里看花



下面是学习资料

入门： [菜鸟教程](http://www.runoob.com/css/css-tutorial.html)(从头看到尾就入门了)



#### 书籍类，写css半年后，在看下面两本书。

难度中级，重实践，包含CSS2和CSS3新特性《CSS揭秘》，W3C委员会委员 LEA VEROU著

难度高级：《CSS世界》 重理论,CSS2深入讲解，阅文的张鑫旭写的



####文档类（查阅API）：

CSS官方文档： [MDN CSS：层叠样式表](https://developer.mozilla.org/zh-CN/docs/Web/CSS)

国内文档：[w3school](http://www.w3school.com.cn/)



####实战篇：（css 提高实战）

仿站，仿各种效果



### 3.JS是 前端的重点

JS 入门要看书

《JavaScript DOM 编程艺术》，读完这本就对DOM 有了解

《JavaScript 权威指南》和《JavaScript 高级程序设计》，读完对 DOM，BOM，ECMA 5 熟悉



三本书读完，可以写实战项目



实战项目

- pc端
  - 官网
  - 后台
- 移动端
  - 移动端，浏览器
  - 小程序
  - app 内嵌页





























