# CSS入门

css学习在于实践和总结，换句话说光看不写是雾里看花



下面是学习资料

入门： [菜鸟教程](http://www.runoob.com/css/css-tutorial.html)(从头看到尾就入门了)



#### 书籍类

难度中级，重实践，包含CSS2和CSS3新特性《CSS揭秘》，W3C委员会委员 LEA VEROU著

难度高级：《CSS世界》 重理论,CSS2深入讲解，阅文的张鑫旭写的



####文档类（查阅API）：

CSS官方文档： [MDN CSS：层叠样式表](https://developer.mozilla.org/zh-CN/docs/Web/CSS)

国内文档：[w3school](http://www.w3school.com.cn/)



高手篇：

仿站，仿各种效果